# 멀티캠퍼스 식단 Chrome Extension

멀티캠퍼스 20층 및 10층 식당의 식단을 한눈에 확인할 수 있는 Chrome Extension입니다.

## ✨ 주요 기능

- 📅 **날짜 선택**: 원하는 날짜의 식단 확인
- 🏢 **20층 (웰스토리)**: A코스/B코스 메뉴, 사진, 영양 정보
- 🍱 **10층 (공존식당)**: 도시락/브런치/샐러드 메뉴
- 🖼️ **이미지 미리보기**: 썸네일 클릭 시 큰 이미지 팝업
- 📊 **영양 정보**: 칼로리, 탄수화물, 단백질, 지방 정보
- 🎨 **압축 레이아웃**: 스크롤 없이 한 화면에 모든 메뉴 표시

## 🌐 데이터 소스

- **20층**: `https://raw.githubusercontent.com/C4T4767/ssabap/main/data/YYYY-MM-DD.json`
- **10층**: `https://raw.githubusercontent.com/C4T4767/ssabap/main/data-10f/YYYY-MM-DD.json`

## 🎨 UI 특징

- **압축 보드형 레이아웃**: 카드 UI 대신 공간 효율적인 보드 UI
- **인라인 메뉴 칩**: 메뉴를 칩 형태로 압축 표시
- **썸네일 이미지**: 오른쪽에 80x80 썸네일, 클릭 시 큰 이미지
- **아이콘 버튼**: ℹ️ (영양정보)
- **총 칼로리 강조**: 메인 메뉴와 총 칼로리를 헤더에 표시

## 📝 파일 구조

```
multicampus-menu-extension/
├── manifest.json       # Extension 설정
├── popup.html          # 팝업 HTML
├── popup.js            # 메뉴 로드 로직
├── styles.css          # 스타일
├── icons/              # 아이콘 이미지
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md           # 이 파일
```

## 🐛 문제 해결

### 메뉴가 안 보여요
- GitHub 리포지토리에 해당 날짜의 JSON 파일이 있는지 확인
- 개발자 도구(F12) 콘솔에서 에러 확인

### 이미지가 안 보여요
- 이미지 URL이 유효한지 확인
- 네트워크 연결 확인

### 캐시 문제
- Extension에서 자동으로 1분마다 캐시 무효화
- 강제 새로고침: `chrome://extensions/`에서 새로고침

## 📄 라이선스

MIT License
